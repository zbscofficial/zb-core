-- Placeholder for shared client functions
ZBCore = {}

function ZBCore.Notify(text, type)
    TriggerEvent('QBCore:Notify', text, type or 'primary')
end
