-- Placeholder for shared client functions

exports("NotifyClient", function(msg, type)
    TriggerEvent('QBCore:Notify', msg, type or "primary")
end)
