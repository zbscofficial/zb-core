-- zb-core/server/main.lua
exports("Notify", function(source, msg, type)
    TriggerClientEvent('QBCore:Notify', source, msg, type or "primary")
end)
