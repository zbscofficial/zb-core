-- Placeholder for shared server functions
ZBCore = {}

function ZBCore.Log(text)
    print("[ZB-Core] " .. text)
end
