fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'ZB Scripts'
description 'zb-core - Core utilities for all zb scripts'
version '1.0.0'


server_scripts {
    'server/main.lua'
}

client_scripts {
    'client/main.lua'
}

exports {
    'Notify',
    'NotifyClient'
}
